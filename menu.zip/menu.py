import pygame
import os
import random
import datetime


class Cat(pygame.sprite.Sprite):
    def __init__(self, avatars, sheet, columns, rows, x, y):
        super().__init__(all_sprites)
        self.alex = pygame.sprite.Group()
        self.alex.add(avatars[0])
        self.kirill = pygame.sprite.Group()
        self.kirill.add(avatars[1])
        self.ilya = pygame.sprite.Group()
        self.ilya.add(avatars[2])
        self.x = 0
        self.frames = []
        self.cut_sheet(sheet, columns, rows)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(x, y)

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns,
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self):
        global running
        self.x += 1
        text = pygame.font.SysFont('comicsansms', 72).render('"KupiTeam" Presents', True, pygame.Color('white'))
        screen.blit(text, (250, 750))
        if self.x >= 10:
            self.alex.draw(screen)
            text = pygame.font.SysFont(None, 40).render('Александр Буренчев', True, pygame.Color('green'))
            screen.blit(text, (20, 415))
        if self.x >= 25:
            self.kirill.draw(screen)
            text = pygame.font.SysFont(None, 40).render('Кирилл Золотарев', True, pygame.Color('red'))
            screen.blit(text, (400, 415))
        if self.x >= 40:
            self.ilya.draw(screen)
            text = pygame.font.SysFont(None, 40).render('Илья Борисов', True, pygame.Color('purple'))
            screen.blit(text, (780, 415))
        if self.x >= 80:
            running = False
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]
        self.rect.x += 20


pygame.init()
FPS = 5
all_sprites = pygame.sprite.Group()
alex = pygame.sprite.Sprite()
kirill = pygame.sprite.Sprite()
ilya = pygame.sprite.Sprite()
todd = pygame.sprite.Sprite()
clock = pygame.time.Clock()
size = width, height = 1200, 960
screen = pygame.display.set_mode(size)
running = True
screen.fill((0, 0, 0))
image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/cat.png')), (300, 300))
alex.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/alex.jpg')), (400, 415))
kirill.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/kirill.png')), (400, 415))
todd.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/todd.jpg')), (1200, 400))
ilya.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/ilya.jpg')), (400, 415))
alex.rect = alex.image.get_rect()
ilya.rect = ilya.image.get_rect()
todd.rect = todd.image.get_rect()
kirill.rect = kirill.image.get_rect()
alex.rect.x = 20
alex.rect.y = kirill.rect.y = ilya.rect.y = todd.rect.x = 0
kirill.rect.x = 400
ilya.rect.x = 780
todd.rect.y = 600
all_sprites.add(todd)
Cat((alex, kirill, ilya), image, 1, 2, -150, 455)
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
            running = False
    screen.fill(pygame.Color('black'))
    all_sprites.draw(screen)
    all_sprites.update()
    pygame.display.flip()
    clock.tick(FPS)


class Text:
    def update(self):
        screen.blit(text, (0, 0))


pygame.mixer.music.load('data/sounds/menu music.mp3')
pygame.mixer.music.set_volume(0.1)
pygame.mixer.music.play()
text = pygame.font.SysFont(None, 72).render('XCOM     click to continue', True, pygame.Color('purple'))
bg = pygame.sprite.Sprite()
bg.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/background.jpg')), (1200, 960))
bg.rect = bg.image.get_rect()
bg.rect.x = 0
bg.rect.y = 0
all_sprites.add(bg)
screen.fill((0, 0, 0))
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
            running = False
    screen.fill(pygame.Color('black'))
    all_sprites.draw(screen)
    Text.update(Text())
    pygame.display.flip()
    clock.tick(FPS)

class Map:
    def __init__(self, what_a_maps):
        self.play_btn = pygame.sprite.Group()

        btn = pygame.sprite.Sprite()
        btn.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/btn.png')), (70, 70))
        btn.rect = btn.image.get_rect()
        btn.rect.x = what_a_maps[0][0]
        btn.rect.y = what_a_maps[0][1]
        btn1 = pygame.sprite.Sprite()
        btn1.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/btn.png')), (70, 70))
        btn1.rect = btn1.image.get_rect()
        btn1.rect.x = what_a_maps[1][0]
        btn1.rect.y = what_a_maps[1][1]
        self.play_btn.add(btn)
        self.play_btn.add(btn1)

    def update(self):
        screen.blit(time, (280, 0))
        self.play_btn.draw(screen)


class Text:
    def introduction(self):
        if flag_text:
            screen.blit(text1, (500, 200))
            screen.blit(text2, (220, 250))
            screen.blit(text3, (190, 300))
            screen.blit(text4, (320, 350))
            screen.blit(text5, (270, 400))
            screen.blit(text6, (200, 450))
            screen.blit(text7, (220, 500))
            screen.blit(text8, (180, 550))
            screen.blit(text9, (250, 600))
            screen.blit(text10, (290, 650))
            screen.blit(text11, (220, 700))
            screen.blit(text12, (250, 750))
            screen.blit(text13, (260, 800))
        else:
            screen.blit(no_text, (0, 0))

    def panic(self):
        # Проверка из бд:
        # Южная Америка
        screen.blit(panic1, (250, 650))  # Или другой уровень паники, этот по умолчанию
        # Африка
        screen.blit(panic1, (630, 550))  # Или другой уровень паники, этот по умолчанию
        # Северная Америка
        screen.blit(panic1, (140, 250))  # Или другой уровень паники, этот по умолчанию
        # Австралия
        screen.blit(panic1, (1100, 810))  # Или другой уровень паники, этот по умолчанию
        # Евразия
        screen.blit(panic1, (700, 200))  # Или другой уровень паники, этот по умолчанию


pygame.display.set_caption("Global map")
map = pygame.sprite.Group()
bg.image = pygame.transform.scale(pygame.image.load(os.path.join('data/Текстуры/map.jpg')), (1200, 960))
bg.rect = bg.image.get_rect()
bg.rect.x = bg.rect.y = 0
map.add(bg)

flag_text = True

text = ['Поздравляю!', 'Вас повысили! Теперь вы командующий', 'опергруппы. В данный момент идет первая',
        'галактическая война на Марсе', 'на базе пришельцев. Но на Землю', 'продолжают нападать маленькие отряды',
        'партизан. Ваша задача уничтожить эти', 'отряды и восстановить порядок на Земле.',
        'Они напали на наш генератор и наша', 'система питания была повреждена.', 'Энергии хватило на вывод карты мира',
        'в ужасном качестве. Это всё, что мы ', 'можем сделать. Удачи, командир!']

text1 = pygame.font.SysFont(None, 60).render(text[0], True, (100, 255, 100), pygame.Color('black'))
text2 = pygame.font.SysFont(None, 60).render(text[1], True, (100, 255, 100), pygame.Color('black'))
text3 = pygame.font.SysFont(None, 60).render(text[2], True, (100, 255, 100), pygame.Color('black'))
text4 = pygame.font.SysFont(None, 60).render(text[3], True, (100, 255, 100), pygame.Color('black'))
text5 = pygame.font.SysFont(None, 60).render(text[4], True, (100, 255, 100), pygame.Color('black'))
text6 = pygame.font.SysFont(None, 60).render(text[5], True, (100, 255, 100), pygame.Color('black'))
text7 = pygame.font.SysFont(None, 60).render(text[6], True, (100, 255, 100), pygame.Color('black'))
text8 = pygame.font.SysFont(None, 60).render(text[7], True, (100, 255, 100), pygame.Color('black'))
text9 = pygame.font.SysFont(None, 60).render(text[8], True, (100, 255, 100), pygame.Color('black'))
text10 = pygame.font.SysFont(None, 60).render(text[9], True, (100, 255, 100), pygame.Color('black'))
text11 = pygame.font.SysFont(None, 60).render(text[10], True, (100, 255, 100), pygame.Color('black'))
text12 = pygame.font.SysFont(None, 60).render(text[11], True, (100, 255, 100), pygame.Color('black'))
text13 = pygame.font.SysFont(None, 60).render(text[12], True, (100, 255, 100), pygame.Color('black'))
no_text = pygame.font.SysFont(None, 72).render('', True, pygame.Color('black'))

panic = ['УП: 0', 'УП: 1', 'УП: 2']

panic1 = pygame.font.SysFont(None, 40).render(panic[0], True, (0, 0, 0))
panic2 = pygame.font.SysFont(None, 40).render(panic[1], True, (0, 0, 0))
panic3 = pygame.font.SysFont(None, 40).render(panic[2], True, (0, 0, 0))


screen.fill((0, 0, 0))

FPS = 0.5
running = True
x = [0, 0]
while x[0] == x[1]:
    x = random.choices([(210, 500), (600, 450), (200, 250), (1100, 730), (600, 200)], k=2)
print(x)
in_game = True
time_rn = datetime.datetime.now()
while running:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
            flag_text = False

    if in_game:
        time_rn += datetime.timedelta(days=14)
        time = pygame.font.SysFont(None, 72).render(str(time_rn).split()[0].replace('-', '.'),
                                                    True, pygame.Color('black'))
        screen.fill(pygame.Color('black'))
        map.draw(screen)
        Map.update(Map(x))
        Text.panic(Text())
        Text.introduction(Text())
        pygame.display.flip()
        clock.tick(FPS)
    else:
        pass
