<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="water" tilewidth="32" tileheight="32" tilecount="2116" columns="46">
 <image source="Текстуры/water.jpg" width="1500" height="1500"/>
</tileset>
