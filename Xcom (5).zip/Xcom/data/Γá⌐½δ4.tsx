<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="тайлы4" tilewidth="32" tileheight="32" tilecount="360" columns="18">
 <image source="Текстуры/тайлы4.png" width="593" height="668"/>
</tileset>
