<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="laba" tilewidth="32" tileheight="32" tilecount="2" columns="1">
 <image source="Текстуры/laba.png" width="32" height="64"/>
</tileset>
