<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="stand" tilewidth="32" tileheight="32" tilecount="7" columns="7">
 <image source="Текстуры/stand.png" width="224" height="32"/>
</tileset>
