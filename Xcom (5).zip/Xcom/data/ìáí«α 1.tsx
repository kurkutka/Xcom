<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="Набор 1" tilewidth="32" tileheight="32" tilecount="484" columns="22">
 <image source="Текстуры/набор тайлов 3.jpg" width="735" height="734"/>
</tileset>
