<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="тайлы2" tilewidth="32" tileheight="32" tilecount="456" columns="38">
 <image source="Текстуры/набор тайлов 1.png" width="1218" height="386"/>
</tileset>
