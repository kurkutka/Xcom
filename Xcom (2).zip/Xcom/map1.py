import pygame
from pytmx.util_pygame import load_pygame
import os
import math
from move import Move
from fire import Fire
from chance import Chance

pygame.init()
size = width, height = 1200, 960
screen = pygame.display.set_mode(size)
running = True
global s, flag, choice_hero, hero, error_tail, way, choice_hero1, choice_hero2, choice_hero3, flag_turn, flag_turn1, \
    flag_turn2, flag_turn3, turn_enemy, choice_alien, destr, health_hero, health_alien, fire, hit
s = [[2, 4], [2, 5], [2, 3], [3, 3], [3, 2], [4, 2], [5, 2], [6, 2], [7, 2], [8, 2], [9, 2], [10, 2], [11, 2], [12, 2],
     [13, 2], [14, 2], [15, 2], [16, 2], [16, 3], [16, 5], [16, 6], [15, 6], [14, 6], [13, 6], [12, 6], [11, 6],
     [10, 6], [8, 6], [9, 6], [7, 6], [6, 6], [5, 6], [4, 6], [3, 6], [2, 5], [3, 5], [7, 6], [9, 9], [9, 10], [9, 11],
     [18, 14], [18, 15], [18, 16], [15, 12], [14, 12], [13, 12], [13, 11], [13, 10], [14, 10], [15, 10], [14, 19],
     [15, 19], [16, 19], [17, 19], [18, 19], [18, 20], [18, 21], [18, 22], [18, 22], [18, 23], [18, 24], [18, 25],
     [17, 25], [16, 25], [15, 25], [14, 25], [14, 24], [14, 23], [14, 21], [14, 21], [14, 20], [14, 19], [7, 26],
     [6, 26], [6, 27], [5, 27], [4, 27], [4, 26], [3, 26], [3, 25], [3, 24], [3, 23], [3, 22], [3, 21], [3, 20],
     [3, 19], [3, 18], [3, 17], [3, 16], [3, 15], [4, 15], [4, 14], [5, 14], [6, 14], [6, 15], [7, 15], [7, 16],
     [7, 17], [7, 19], [7, 20], [7, 21], [7, 21], [7, 22], [7, 23], [7, 24], [7, 25], [7, 25], [18, 14], [18, 15],
     [18, 16], [24, 19], [25, 19], [25, 18], [24, 18], [22, 7], [23, 7], [23, 6], [22, 6]]
flag = [2000, 2000]
hero = 0
error_tail = 0
way = 0
fire = 0
health_hero = [6, 5, 4, 5]
health_alien = [5, 5, 5, 5, 5, 5, 5, 5, 5]
choice_hero = [28, 11]  # саппорт
choice_hero1 = [28, 10]  # штурмовик
choice_hero2 = [29, 9]  # снайпер
choice_hero3 = [29, 12]  # медик
flag_turn = 0  # флаг хода саппорта
flag_turn1 = 0  # флаг хода штурмовика
flag_turn2 = 0  # флаг хода снайпера
flag_turn3 = 0  # флаг хода медика
turn_enemy = 0  # флаг хода клятых алиенов
hit = 0
choice_alien = [[3, 4], [4, 3], [4, 5], [5, 9], [5, 11],
                [5, 17], [5, 19], [16, 21],
                [16, 23]]  # список клятых алиенов (сектоидов)
destr = []  # список разрушений

tmxdata = load_pygame("data/map1.1.tmx")


class XCOM:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.cell_size = 32

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self):
        for x in range(30):
            for y in range(30):
                for elem in choice_alien:
                    screen.blit(sectoid, (elem[1] * 32, elem[0] * 32))
                screen.blit(support, (choice_hero[1] * 32, choice_hero[0] * 32))
                screen.blit(eng, (choice_hero1[1] * 32, choice_hero1[0] * 32))
                screen.blit(sniper, (choice_hero2[1] * 32, choice_hero2[0] * 32))
                screen.blit(medic, (choice_hero3[1] * 32, choice_hero3[0] * 32))
                if hero == 1 or hero == 2 or hero == 3 or hero == 4:
                    screen.blit(menu, (960, 0))
                    if hero == 1:
                        screen.blit(sup, (1090, 152))
                        if flag_turn == 1:
                            screen.blit(action, (965, 176))
                        if flag_turn == 0:
                            screen.blit(action, (965, 176))
                            screen.blit(action, (1080, 176))
                    elif hero == 2:
                        screen.blit(en, (1090, 152))
                        if flag_turn1 == 1:
                            screen.blit(action, (965, 176))
                        if flag_turn1 == 0:
                            screen.blit(action, (965, 176))
                            screen.blit(action, (1080, 176))
                    elif hero == 3:
                        screen.blit(sn, (1090, 152))
                        if flag_turn2 == 1:
                            screen.blit(action, (965, 176))
                        if flag_turn2 == 0:
                            screen.blit(action, (965, 176))
                            screen.blit(action, (1080, 176))
                    elif hero == 4:
                        screen.blit(md, (1090, 152))
                        if flag_turn3 == 1:
                            screen.blit(action, (965, 176))
                        if flag_turn3 == 0:
                            screen.blit(action, (965, 176))
                            screen.blit(action, (1080, 176))
                if x == flag[1] and y == flag[0]:
                    screen.blit(red, (flag[1] * 32, flag[0] * 32))
                elif [x * 32, y * 32] in destr:
                    screen.blit(del_bl, (x * 32, y * 32))
                else:
                    screen.blit((tmxdata.get_tile_image(x, y, 0)), (x * 32, y * 32))
                if error_tail == 1:
                    screen.blit(red, (s1[1] * 32, s1[0] * 32))
                if fire == 2:
                    screen.blit(ffire, (965, 208))
                    screen.blit(shoot, (970, 230))
                if fire == 1:
                    screen.blit(ire, (965, 208))
                    screen.blit(shoot, (970, 230))
                if fire == 3:
                    screen.blit(re, (965, 208))

    def get_cell(self, mouse_pos):
        if mouse_pos[0] < self.width * self.cell_size and \
                mouse_pos[1] < self.height * self.cell_size:
            x = (mouse_pos[0]) // self.cell_size
            y = (mouse_pos[1]) // self.cell_size
            return y, x  # обратите внимание!!!!!
        else:
            return None

    def get_click(self, mouse_pos):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell)

    def on_click(self, cell):
        if cell != None:
            pass


def load_image1(name):
    fullname = os.path.join('data/Текстуры', name)
    image = pygame.image.load(fullname).convert()
    return image


def load_image(name):
    fullname = os.path.join('data/Текстуры', name)
    image = pygame.image.load(fullname)
    return image


board = XCOM(30, 30)
running = True
clock = pygame.time.Clock()
global_menu = load_image1('global_menu.png')
menu = load_image1('menut.png')
support = load_image('Heavy_support.png')
eng = load_image('Engeniiiiiier.png')
sniper = load_image('sniper.png')
medic = load_image('medic.png')
red = load_image('red_sqr.png')
sectoid = load_image('sectoid.png')
del_bl = load_image('del_blok.png')
action = load_image1('action.png')
shoot = load_image1('shoot.png')
text_menu = pygame.font.Font(None, 24)
sup = text_menu.render('Поддержка', 0, (0, 0, 0))
en = text_menu.render('Инженер', 0, (0, 0, 0))
sn = text_menu.render('Снайпер', 0, (0, 0, 0))
md = text_menu.render('Медик', 0, (0, 0, 0))
ffire = text_menu.render('Шанс попадания - ' + str(hit), 0, (0, 0, 0))
ire = text_menu.render('Вы не поразите цель.', 0, (0, 0, 0))
re = text_menu.render('Вам не хватает дальности', 0, (0, 0, 0))
wall = pygame.sprite.Group()
for elem in s:
    sprite = pygame.sprite.Sprite()
    sprite.image = load_image("blue wall.png")
    sprite.rect = sprite.image.get_rect()
    wall.add(sprite)
    sprite.rect.x = elem[1] * 32
    sprite.rect.y = elem[0] * 32
wall.draw(screen)
fire_line = load_image("red_sqr.png")
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                board.get_click(event.pos)
                if event.pos[0] <= 1024 and event.pos[1] <= 1024:
                    s1 = [board.get_cell(event.pos)[0], board.get_cell(event.pos)[1]]
                if s1 in s:
                    flag = s1
                if hero != 0 and s1 in choice_alien:
                    if hero == 1 and flag_turn != 2:
                        sd = Fire.fire(Fire(), choice_hero[0], choice_hero[1], s1[0], s1[1], fire_line, wall, 5,
                                       screen)
                        if sd == 1:
                            fire = 3
                        elif sd:
                            fire = 1
                            for elem in sd:
                                if [elem[1] // 32, elem[0] // 32] in s:
                                    del s[s.index([elem[1] // 32, elem[0] // 32])]
                                destr.append(elem)
                        else:
                            flag_turn = 2
                            fire = 2
                            hit = Chance.hit(Chance(), choice_hero[0], choice_hero[1], s1[0], s1[1], s)
                            ffire = text_menu.render('Шанс попадания - ' + str(hit), 0, (0, 0, 0))
                    elif hero == 2 and flag_turn1 != 2:
                        sd = Fire.fire(Fire(), choice_hero1[0], choice_hero1[1], s1[0], s1[1], fire_line, wall, 4,
                                       screen)
                        if sd == 1:
                            fire = 3
                        elif sd:
                            fire = 1
                            for elem in sd:
                                if [elem[1] // 32, elem[0] // 32] in s:
                                    del s[s.index([elem[1] // 32, elem[0] // 32])]
                                destr.append(elem)
                        else:
                            flag_turn1 = 2
                            fire = 2
                            hit = Chance.hit(Chance(), choice_hero[0], choice_hero[1], s1[0], s1[1], s)
                            ffire = text_menu.render('Шанс попадания - ' + str(hit), 0, (0, 0, 0))
                    elif hero == 3 and flag_turn2 == 0:
                        sd = Fire.fire(Fire(), choice_hero2[0], choice_hero2[1], s1[0], s1[1], fire_line, wall, 7,
                                       screen)
                        if sd == 1:
                            fire = 3
                        elif sd:
                            fire = 1
                            for elem in sd:
                                if [elem[1] // 32, elem[0] // 32] in s:
                                    del s[s.index([elem[1] // 32, elem[0] // 32])]
                                destr.append(elem)
                        else:
                            flag_turn2 = 2
                            fire = 2
                            hit = Chance.hit(Chance(), choice_hero[0], choice_hero[1], s1[0], s1[1], s)
                            ffire = text_menu.render('Шанс попадания - ' + str(hit), 0, (0, 0, 0))
                    elif hero == 4 and flag_turn3 != 2:
                        sd = Fire.fire(Fire(), choice_hero3[0], choice_hero3[1], s1[0], s1[1], fire_line, wall, 5,
                                       screen)
                        if sd == 1:
                            fire = 3
                        elif sd:
                            fire = 1
                            for elem in sd:
                                if [elem[1] // 32, elem[0] // 32] in s:
                                    del s[s.index([elem[1] // 32, elem[0] // 32])]
                                destr.append(elem)
                        else:
                            flag_turn3 = 2
                            fire = 2
                            hit = Chance.hit(Chance(), choice_hero[0], choice_hero[1], s1[0], s1[1], s)
                            ffire = text_menu.render('Шанс попадания - ' + str(hit), 0, (0, 0, 0))
                if s1 not in choice_alien:
                    if s1 == choice_hero:  # support
                        if s1 not in s:
                            hero = 1
                            error_tail = 0
                            choice_hero = s1
                    if s1 != choice_hero and hero == 1:
                        if s1 not in s and Move.way(Move(), s, choice_hero[1], choice_hero[0], s1[1], s1[0], 7) \
                                and flag_turn != 2 and s1 != choice_hero2 and s1 != choice_hero3 and s1 != choice_hero1:
                            choice_hero = s1
                            hero = 0
                            flag_turn += 1
                            error_tail = 0
                            flag[0] = flag[0] + 1000
                        else:
                            error_tail = 1
                    if s1 == choice_hero1:  # eng
                        if s1 not in s:
                            hero = 2
                            error_tail = 0
                            choice_hero1 = s1
                    if s1 != choice_hero1 and hero == 2:
                        if s1 not in s and Move.way(Move(), s, choice_hero1[1], choice_hero1[0], s1[1], s1[0], 9) \
                                and flag_turn1 != 2 and s1 != choice_hero2 and s1 != choice_hero and s1 != choice_hero3:
                            choice_hero1 = s1
                            hero = 0
                            flag_turn1 += 1
                            error_tail = 0
                            flag[0] = flag[0] + 1000
                        else:
                            error_tail = 1

                    if s1 == choice_hero2:  # sniper
                        if s1 not in s:
                            hero = 3
                            error_tail = 0
                            choice_hero2 = s1
                    if s1 != choice_hero2 and hero == 3:
                        if s1 not in s and Move.way(Move(), s, choice_hero2[1], choice_hero2[0], s1[1], s1[0], 7) \
                                and flag_turn2 != 2 and s1 != choice_hero3 and s1 != choice_hero and s1 != choice_hero1:
                            choice_hero2 = s1
                            hero = 0
                            error_tail = 0
                            flag_turn2 += 1
                            flag[0] = flag[0] + 1000
                        else:
                            error_tail = 1

                    if s1 == choice_hero3:  # medic
                        if s1 not in s:
                            hero = 4
                            error_tail = 0
                            choice_hero3 = s1
                    if s1 != choice_hero3 and hero == 4:
                        if s1 not in s and Move.way(Move(), s, choice_hero3[1], choice_hero3[0], s1[1], s1[0], 9) \
                                and flag_turn3 != 2 and s1 != choice_hero2 and s1 != choice_hero and s1 != choice_hero1:
                            choice_hero3 = s1
                            hero = 0
                            error_tail = 0
                            flag_turn3 += 1
                            flag[0] = flag[0] + 1000
                        else:
                            error_tail = 1
                if event.pos[0] > 1100 and event.pos[1] > 870:
                    flag_turn = 0
                    flag_turn1 = 0
                    flag_turn2 = 0
                    flag_turn3 = 0
                    turn_enemy = 1
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                flag_turn = 0
                flag_turn1 = 0
                flag_turn2 = 0
                flag_turn3 = 0
                turn_enemy = 1
    board.render()
    clock.tick(10)
    pygame.display.flip()
