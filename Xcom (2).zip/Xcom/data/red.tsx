<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="red" tilewidth="32" tileheight="32" tilecount="625" columns="25">
 <image source="Текстуры/red_sqr.jpg" width="810" height="810"/>
</tileset>
