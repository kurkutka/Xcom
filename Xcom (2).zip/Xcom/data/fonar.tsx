<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="fonar" tilewidth="32" tileheight="32" tilecount="9" columns="3">
 <image source="Текстуры/fonar.png" width="96" height="96"/>
</tileset>
