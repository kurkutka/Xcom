<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="door" tilewidth="32" tileheight="32" tilecount="625" columns="25">
 <image source="Текстуры/доски.jpg" width="800" height="800"/>
</tileset>
