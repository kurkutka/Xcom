<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="docki" tilewidth="1" tileheight="1" tilecount="640000" columns="800">
 <image source="data/Текстуры/доски.jpg" width="800" height="800"/>
</tileset>
