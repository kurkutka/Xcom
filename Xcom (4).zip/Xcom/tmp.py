import pygame

print(pygame.font.get_fonts())
