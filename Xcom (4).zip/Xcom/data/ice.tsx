<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="ice" tilewidth="32" tileheight="32" tilecount="496" columns="31">
 <image source="Текстуры/ice.jpg" width="1023" height="528"/>
</tileset>
